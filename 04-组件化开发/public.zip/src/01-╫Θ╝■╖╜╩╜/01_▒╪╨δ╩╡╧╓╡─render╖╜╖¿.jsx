import React from "react";

class App extends React.Component {
  // 类组件中唯一必须实现的方法
  render() {
    return <h2>我是render方法</h2>;
  }
}

export default App;
