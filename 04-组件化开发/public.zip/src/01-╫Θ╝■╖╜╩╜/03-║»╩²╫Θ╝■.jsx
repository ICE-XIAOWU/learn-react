function App() {
  return <h2>我是函数组件</h2>;
}

export default App;
