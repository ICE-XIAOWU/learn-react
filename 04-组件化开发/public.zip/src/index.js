import ReactDOM from "react-dom/client";
import App from "./06-实现插槽/App";

const root = ReactDOM.createRoot(document.querySelector("#root"));

root.render(<App />);
